.MODEL SMALL
.STACK 100H
.DATA
    STR DB 'MADAM$',0     ; change string here
    MSG1 DB 'Palindrome$'
    MSG2 DB 'Not Palindrome$'

.CODE
MAIN:
    MOV AX, @DATA
    MOV DS, AX

    LEA SI, STR       ; SI ? start of string
    MOV CX, 0         ; counter = 0

PUSH_LOOP:
    MOV AL, [SI]
    CMP AL, '$'
    JE CHECK

    PUSH AX           
    INC SI
    INC CX            
    JMP PUSH_LOOP
    
CHECK:
    LEA SI, STR       

COMPARE_LOOP:
    CMP CX, 0
    JE PALINDROME     

    MOV AL, [SI]      
    POP BX            

    CMP AL, BL        
    JNE NOT_PALIN

    INC SI
    DEC CX
    JMP COMPARE_LOOP

PALINDROME:
    LEA DX, MSG1
    MOV AH, 09H
    INT 21H
    JMP END_PROGRAM

NOT_PALIN:
    LEA DX, MSG2
    MOV AH, 09H
    INT 21H

END_PROGRAM:
    MOV AH, 4CH
    INT 21H

END MAIN




