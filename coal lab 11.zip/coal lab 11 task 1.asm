.MODEL SMALL
.STACK 100H
.DATA
    STR DB 'HELLO$',0   
    COUNT DW 0

.CODE
MAIN:
    MOV AX, @DATA
    MOV DS, AX

    LEA SI, STR     
    MOV CX, 0       

PUSH_LOOP:
    MOV AL, [SI]    
    CMP AL, '$'     
    JE DONE

    PUSH AX         
    INC CX          
    INC SI          
    JMP PUSH_LOOP

DONE:
    MOV COUNT, CX   
    MOV AH, 4CH
    INT 21H

END MAIN




