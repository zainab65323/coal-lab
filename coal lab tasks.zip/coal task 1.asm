.model small
.stack 100h
.data

.code
main proc
    mov ax, @data
    mov ds, ax

    ; Print H
    mov ah, 02h
    mov dl, 'H'
    int 21h

    ; Print E
    mov dl, 'E'
    int 21h

    ; Print L
    mov dl, 'L'
    int 21h

    ; Print L
    mov dl, 'L'
    int 21h

    ; Print O
    mov dl, 'O'
    int 21h

    mov ah, 4Ch
    int 21h
main endp
end main
