.model small
.stack 100h

.data
    msg1 db 'Enter number of elements: $'
    msg2 db 0Dh,0Ah,'Enter elements:$'
    msg3 db 0Dh,0Ah,'Sum = $'
    
    arr db 10 dup(?)   
    n db ?             
    sum db 0

.code
main proc
    mov ax, @data
    mov ds, ax

    
    lea dx, msg1
    mov ah, 09h
    int 21h

    mov ah, 01h       
    int 21h
    sub al, 30h       
    mov n, al

   
    lea dx, msg2
    mov ah, 09h
    int 21h

    
    mov cl, n
    mov si, 0

input_loop:
    mov ah, 01h
    int 21h
    sub al, 30h
    mov arr[si], al
    inc si
    loop input_loop

  
    mov cl, n
    mov si, 0
    mov al, 0

sum_loop:
    add al, arr[si]
    inc si
    loop sum_loop

    mov sum, al

    
    lea dx, msg3
    mov ah, 09h
    int 21h

    mov dl, sum
    add dl, 30h       
    mov ah, 02h
    int 21h

    
    mov ah, 4Ch
    int 21h

main endp
end main