.model small
.stack 100h

.data
    msg1 db 'Enter number of elements: $'
    msg2 db 0Dh,0Ah,'Enter elements:$'
    msg3 db 0Dh,0Ah,'Reverse order:$'

    arr db 10 dup(?)   
    n db ?

.code
main proc
    mov ax, @data
    mov ds, ax

  
    lea dx, msg1
    mov ah, 09h
    int 21h

    mov ah, 01h
    int 21h
    sub al, 30h
    mov n, al

    
    lea dx, msg2
    mov ah, 09h
    int 21h

    mov cl, n
    mov si, 0

input_loop:
    mov ah, 01h
    int 21h
    sub al, 30h
    mov arr[si], al
    inc si
    loop input_loop

    
    lea dx, msg3
    mov ah, 09h
    int 21h

    mov cl, n
    dec cl            
    mov si, cx      

reverse_loop:
    mov dl, arr[si]
    add dl, 30h
    mov ah, 02h
    int 21h

    dec si
    cmp si, -1
    jne reverse_loop

    
    mov ah, 4Ch
    int 21h

main endp
end main




