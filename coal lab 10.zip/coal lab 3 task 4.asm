.model small
.stack 100h

.data
    msg1 db 'Enter number of elements: $'
    msg2 db 0Dh,0Ah,'Enter elements:$'
    msg3 db 0Dh,0Ah,'Total even numbers = $'

    arr db 10 dup(?)  
    n db ?
    count db 0

.code
main proc
    mov ax, @data
    mov ds, ax

   
    lea dx, msg1
    mov ah, 09h
    int 21h

    mov ah, 01h
    int 21h
    sub al, 30h
    mov n, al

   
    lea dx, msg2
    mov ah, 09h
    int 21h

    mov cl, n
    mov si, 0

input_loop:
    mov ah, 01h
    int 21h
    sub al, 30h
    mov arr[si], al
    inc si
    loop input_loop

    
    mov cl, n
    mov si, 0
    mov bl, 0      

check_loop:
    mov al, arr[si]
    and al, 1       
    cmp al, 0
    jne skip

    inc bl           

skip:
    inc si
    loop check_loop

    mov count, bl

    
    lea dx, msg3
    mov ah, 09h
    int 21h

    mov dl, count
    add dl, 30h
    mov ah, 02h
    int 21h

    
    mov ah, 4Ch
    int 21h

main endp
end main




