.model small
.stack 100h

.data
    msg1 db 'Enter 5 elements:$'
    msg2 db 0Dh,0Ah,'Largest = $'
    
    arr db 5 dup(?)   

.code
main proc
    mov ax, @data
    mov ds, ax

    
    lea dx, msg1
    mov ah, 09h
    int 21h

    
    mov cx, 5
    mov si, 0

input_loop:
    mov ah, 01h
    int 21h
    sub al, 30h
    mov arr[si], al
    inc si
    loop input_loop

    
    mov al, arr[0]

    
    mov cx, 4
    mov si, 1

compare_loop:
    cmp al, arr[si]
    jge skip
    mov al, arr[si]

skip:
    inc si
    loop compare_loop

    
    lea dx, msg2
    mov ah, 09h
    int 21h

    mov dl, al
    add dl, 30h
    mov ah, 02h
    int 21h

    
    mov ah, 4Ch
    int 21h

main endp
end main




