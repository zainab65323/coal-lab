.model small
.stack 100h
.data
msg db "Area = $"
area db ?
tens db ?
ones db ?

.code
main proc
    mov ax,@data
    mov ds,ax

   
    mov al,5      
    mov bl,4      
    mov ah,0     
    mul bl         

    mov area,al    

    
    mov al,area
    mov ah,0
    mov bl,10
    div bl         
    mov tens,al
    mov ones,ah

    
    mov dx,offset msg
    mov ah,9
    int 21h

    
    mov dl,tens
    add dl,48
    mov ah,2
    int 21h

    
    mov dl,ones
    add dl,48
    mov ah,2
    int 21h

    
    mov ah,4ch
    int 21h
main endp
end main