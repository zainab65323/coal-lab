.model small
.stack 100h
.data
msgQ db "Quotient = $"
msgR db "Remainder = $"
quot db ?
rem db ?

.code
main proc
    mov ax,@data
    mov ds,ax

    mov al,27      
    mov ah,0       
    mov bl,10

    div bl        
    mov quot,al
    mov rem,ah

    
    mov dx,offset msgQ
    mov ah,9
    int 21h

    mov dl,quot
    add dl,48
    mov ah,2
    int 21h

   
    mov dl,10
    mov ah,2
    int 21h
    mov dl,13
    int 21h

    
    mov dx,offset msgR
    mov ah,9
    int 21h

    mov dl,rem
    add dl,48
    mov ah,2
    int 21h

    
    mov ah,4ch
    int 21h

main endp
end main